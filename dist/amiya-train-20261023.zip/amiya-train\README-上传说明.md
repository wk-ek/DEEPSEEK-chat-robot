# 上传说明

## 包里有什么

```
amiya-train/
├── train/           训练脚本 + 配置 + run.sh
├── src/             脚本依赖（调 API、读人格）
├── config/          人格档案 + 配置模板
└── package.json
```

**本包不含训练数据**，需要用 `bash run.sh --auto` 现场生成（要剧情文本 + API key）。

## 怎么用

```bash
# 1. 上传并解压到 /workspace
cd /workspace && unzip amiya-train-*.zip
cd amiya-train

# 2. 配 API key（只有 --auto 生成数据时才需要）
cp config/config.example.json config/config.json
export DEEPSEEK_API_KEY=sk-xxxx

# 3. 检查环境
bash train/run.sh --dry

# 4. 开训
bash train/run.sh --auto
```

## 三种训练模式

| 命令 | 做什么 | 产出 |
| --- | --- | --- |
| `bash train/run.sh` | 用已有数据训两阶段 | 纯官方版 |
| `bash train/run.sh --auto` | 现场生成数据再训 | 纯官方版 |
| `bash train/run.sh --official-only` | 只训官方，跳过同人层 | 纯官方版 |

有 `extra.jsonl` 时会自动多训一层同人版，产物是：
- `amiya-official` 纯官方（推荐主用）
- `amiya-extra` 官方 + 同人

## 成本

- 数据生成（--auto）：约 5-10 元 API
- GPU：约 1-1.5 小时，3-5 元
- **合计 8-15 元**

⚠️ 跑完立刻关机。
